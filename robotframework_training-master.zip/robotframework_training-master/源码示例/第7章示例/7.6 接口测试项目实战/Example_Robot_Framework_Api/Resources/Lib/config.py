# coding=utf-8
# 环境配置文件


# 测试环境
# URL = 'https://test.xxx.com'


# 预发布环境
# URL = 'https://pre.xxx.com'


# 生产环境
# URL = 'https://www.xxx.com'


URL = 'https://www.xxx.com'
